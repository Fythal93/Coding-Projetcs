# Maze.py
#   Maze class. Contains an NxN array holding all the cells.
# By: Matt Pagnan

from random import *
from graphics import *
from stack import *

from msvcrt import getch

class Maze:
    def __init__(self, Size):
        """ Constructor for the maze object. Size determines how big the maze arry is going to be """
        # Set up the NxN maze
        self.cellArray = [[cell() for j in range(Size)] for i in range(Size)]
        self.Size = Size # keep track of size of the maze. It's usefull information 

        startSpot = (randrange(Size), randrange(Size))# create a random start location
        self.cellArray[startSpot[0]][startSpot[1]].setState("Start")# set start cell 

        finishSpot = (randrange(Size), randrange(Size))
        self.cellArray[finishSpot[0]][finishSpot[1]].setState("Exit")# set exit cell

        self.recBuild(0,0)# build the maze
        
        # ------------------------ #
        # Find the path to the key #
        # ------------------------ #
        # reset all cells in the cell Array to unvisited for Explore
        # I decided to reuse the Visit boolean for this. This saves space but the
        # cost is it take a little bit longer to compute
        for i in range(Size):
            for j in range(Size):
                self.cellArray[i][j].resetVisit()


        keySpot = (randrange(Size),randrange(Size))# place a key in a random spot in the maze
         
        self.cellArray[keySpot[0]][keySpot[1]].setState("Key")# set that cell as the key cell

        keyStack = self.Explore(startSpot[0], startSpot[1], keySpot[0], keySpot[1]) # find path to the key

        while(keyStack.isEmpty() == False):# take every item from the keyStack
            item = keyStack.pop()
            self.cellArray[item[0]][item[1]].setPath("Key") # set the corespondin cells to keyPath cells

        # ------------------------- #
        # Find the path to the exit #
        # ------------------------- #
        # reset all cells in the cell Array to unvisited for Explore
        # I decided to reuse the Visit boolean for this. This saves space but the
        # cost is it take a little bit longer to compute
        for i in range(Size):
            for j in range(Size):
                self.cellArray[i][j].resetVisit()
                
        exitStack = self.Explore(keySpot[0], keySpot[1], finishSpot[0], finishSpot[1]) # find path from key to exit

        while(exitStack.isEmpty() == False):# take every item from the exitStack
            item = exitStack.pop()
            self.cellArray[item[0]][item[1]].setPath("Exit")# set the corresponding cells to exitPath


    def recBuild(self, cellX, cellY):
        #print(cellX," ",cellY,"",self.cellArray[cellX][cellY].getVisit())
        if(self.cellArray[cellX][cellY].getVisit() == True): #cell has already been visited. return. Base case
          #  print("BASE")
            return False # indicate to the cell before that these cells can share hall

        self.cellArray[cellX][cellY].Visit() #Visit this cell
    
        options = ["N", "E", "S", "W"]# possibe ways we can go
        shuffle(options)# shuffle the options so we check random adjacent cells
        
        #attempt to explore all adjacent cells
        for choice in options:
            if((choice == "N") and cellY > 0):# is there a North cell
                share = self.recBuild(cellX,cellY-1)
                if(share == True):# knock down the walls
                    self.cellArray[cellX][cellY].knockDown("N")
                    self.cellArray[cellX][cellY-1].knockDown("S")
            elif((choice == "E") and cellX < self.Size - 1):# is there an East cell
                share = self.recBuild(cellX+1, cellY)
                if(share == True):# knock down the walls
                    self.cellArray[cellX][cellY].knockDown("E")
                    self.cellArray[cellX+1][cellY].knockDown("W")
            elif((choice == "S") and cellY < self.Size - 1):# is there a South cell                
                share = self.recBuild(cellX, cellY+1)
                if(share == True):# knock down the walls
                    self.cellArray[cellX][cellY].knockDown("S")
                    self.cellArray[cellX][cellY+1].knockDown("N")
            elif((choice == "W") and cellX > 0):# is there a West cell
                share = self.recBuild(cellX-1, cellY)
                if(share == True): # knock down the walls
                    self.cellArray[cellX][cellY].knockDown("W")
                    self.cellArray[cellX-1][cellY].knockDown("E")

        return True # incicate to the cell before that these cells can share a hall

    def Explore(self, startX, startY, endX, endY):

        exploreStack = MyStack() # create the stack containing the path

        # start at the start cell 
        x = startX
        y = startY

        self.cellArray[x][y].Visit()# visit the start cell

        while(x != endX or y != endY):# continue moving to new cells untill we arrive at the end cell
            if(self.cellArray[x][y].getWall("N") == False and self.cellArray[x][y-1].getVisit() == False):# north wall is down and north cell has been unvisited
                    self.cellArray[x][y-1].Visit()
                    exploreStack.push((x,y))# add this cell to the array
                    y = y - 1 # move to next cell
            elif(self.cellArray[x][y].getWall("E") == False and self.cellArray[x+1][y].getVisit() == False):# east wall is down and east cell has been unvisited
                    self.cellArray[x+1][y].Visit()
                    exploreStack.push((x,y))# add this cell to the array
                    x = x + 1# move to next cell
            elif(self.cellArray[x][y].getWall("S") == False and self.cellArray[x][y+1].getVisit() == False):# south wall is down and south cell has been unvisited
                    self.cellArray[x][y+1].Visit()
                    exploreStack.push((x,y))# add this cell to the array
                    y = y + 1# move to next cell
            elif(self.cellArray[x][y].getWall("W") == False and self.cellArray[x-1][y].getVisit() == False):# west wall is down and west cell has been unvisited
                    self.cellArray[x-1][y].Visit()
                    exploreStack.push((x,y))# add this cell to the array
                    x = x - 1# move to next cell
            else:# no more paths to take. 
                oldCell = exploreStack.pop()# this cell is a dead end take it off the stack
                x = oldCell[0] # change to previous cell
                y = oldCell[1]

        exploreStack.push((x,y)) # add end cell to the stack 
        return exploreStack

    def draw(self, win):

        #go through all the cells, drawing each one
        for i in range(self.Size):
            for j in range(self.Size):
                self.cellArray[i][j].draw(Point(10+i*25, 10+j*25),win)
                
        

class cell:
    # cell objects contain information about the cell how functions on how to draw it
    def __init__(self):
        """ contructor for the cell object-- all walls are set up """
        self.North = True
        self.East = True
        self.South = True
        self.West = True

        self.isExitPath = False # used to indicate if cell is a part of the path to the exit
        self.isKeyPath = False # used to indicate if cell is part of the path to the key
        self.State = "Normal" #used To keep track of which cells are "special"
        self.Visited = False #used to keep track of which cells have been visited 


    def setPath(self, path):# function used to tell the cell it is a path cell
        if(path == "Exit"):
            self.isExitPath = True
        if(path == "Key"):
            self.isKeyPath = True

    def getWall(self, wall):# return the state of the specified wall
        if(wall == "N"):
            return self.North
        elif(wall == "E"):
            return self.East
        elif(wall == "S"):
            return self.South
        elif(wall == "W"):
            return self.West

    def setState(self,newState):
        self.State = newState

    def knockDown(self, wall):# knock down the specified wall by setting it to false
        if(wall == "N"):
            self.North = False
        elif(wall == "E"):
            self.East = False
        elif(wall == "S"):
            self.South = False
        elif(wall == "W"):
            self.West = False

    def resetVisit(self):
        self.Visited = False

    def Visit(self):
        self.Visited = True
    
    def getVisit(self):# returns if the cell has been visited yet or not
        return self.Visited

    def draw(self, corner, win):
        x = corner.x # x offset
        y = corner.y # y offset
    
        # draw the floor. - Exit and Key path floors are different colours
        if(self.isExitPath and self.isKeyPath):# check to see if cell is both a exit and key path
            rect = Rectangle(Point(x,y),Point(x+25,y+25))
            rect.setFill("yellow1")
            rect.setOutline("yellow1")
            rect.draw(win)
        elif(self.isExitPath == True):
            rect = Rectangle(Point(x,y),Point(x+25,y+25))
            rect.setFill("red1")
            rect.setOutline("red1")
            rect.draw(win)
        elif(self.isKeyPath == True):
            rect = Rectangle(Point(x,y), Point(x+25, y+25))
            rect.setFill("green1")
            rect.setOutline("green1")
            rect.draw(win)

        

        if(self.State == "Start"):# draw a special box to indicate the cell is a start cell
            rect = Rectangle(Point(x+5,y+5),Point(x+20,y+20))
            rect.setFill("green3")
            rect.draw(win)

        if(self.State == "Exit"):# draw a special box to indicate the cell is a exit cell
            rect = Rectangle(Point(x+5,y+5),Point(x+20,y+20))
            rect.setFill("red3")
            rect.draw(win)

        if(self.State == "Key"):# draw a special circle to indicate the cell has a key
            circle = Circle(Point(x + 12.5, y + 12.5), 5)
            circle.setFill("yellow3")
            circle.draw(win)
        
        if (self.North):# if North Wall is still up
            line = Line(Point(x,y),Point(x+25,y))
            line.setWidth(2)
            line.draw(win)
        if(self.East):# if East wall is still up
            line = Line(Point(x+25,y),Point(x+25,y+25))
            line.setWidth(2)
            line.draw(win)
        if(self.South):# if South wall is still up
            line = Line(Point(x+25,y+25), Point(x,y+25))
            line.setWidth(2)
            line.draw(win)
        if(self.West):# if West wall is still up
            line = Line(Point(x,y+25),Point(x,y))
            line.setWidth(3)
            line.draw(win)
        
def main():
    sys.setrecursionlimit(9001)# increase recursive stack size to handle large size mazes
    
    size = eval(input("Please enter in the maze size you want: "))
    print("Generating maze...")

    win = GraphWin("Maze", (25*size) + 20 ,(25*size + 20))# create the window 
    m1 = Maze(size)# create the maze
    m1.draw(win)# draw the maze

    print("Green Box     : Start ")
    print("Red Box       : Exit ")
    print("Yellow Circle : Key ")
    print("Green Path    : Path to the Key ")
    print("Red Path      : Path to the Exit ")
    print("Yellow Path   : Overlap of Path to the Key and to the Exit")
        
        
main()
