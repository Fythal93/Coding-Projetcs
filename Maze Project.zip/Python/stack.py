# stack.py
#   datastructure of a LIFO list
# By: Matt Pagnan

class MyStack:

    def __init__(self):
        self.stack = [] #create an empty stack

    def push(self, item):
        """Adds the item to the top of the stack"""
        self.stack.append(item)

    def pop(self):
        """Removes the top item from the stack and returns it"""
        #if(self.isEmpty() == False):
        return self.stack.pop(len(self.stack)-1)
        #else:
        #    print("Stack is empty!")
        #    return False
        
    def isEmpty(self):
        """Returns True if there are no elements in the stack, otherwise returns False"""
        if (len(self.stack) > 0):
            return False
        else:
            return True

    def size(self):
        """Returns the number of elements in the stack """
        return len(self.stack)
